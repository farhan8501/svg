var w = window,
    d = document,
    e = d.documentElement,
    g = d.getElementById('#vis'),
   // x = w.innerWidth || e.clientWidth || g.clientWidth,
    y = w.innerHeight|| e.clientHeight|| g.clientHeight;
var statusJson= {
        "open": "#d62728",
        "new": "#d62728",
        "In-Progress": "#ff7f0e",
        "on-hold": "#2ff7f0e",
        "closed": "#2ca02c",
        "complete": "#2ca02c"
    };
var category_names=[];
var ticket_statuses=[];
var ticket_severities=[];
var category_dim;
var status_dim;
var severity_dim;
var ticket_statuses_color=[];
var ticket_status_color_scale=['#d62728', '#ff7f0e', '#2ca02c'];
var ticketStatusJSON;
getCategoryJSONData();
function getCategoryJSONData(){

    category_names=
    $.ajax({
          url: '/webkedb/categories',
          type: 'GET',
          timeout: 1000,
          async: false,
          dataType: 'json',
            success: function(response) {
            //  console.log("Inside: " + response);
            }
        }).responseJSON;
   //console.log("Outside: "+category_names);
   return category_names;		   
}
getStatusJSONData();
function getStatusJSONData(){
	ticket_statuses=
	    $.ajax({
	          url: '/webkedb/ticketStatus',
	          type: 'GET',
	          timeout: 1000,
	          async: false,
	          dataType: 'json',
	            success: function(response) {
	              //console.log("Inside: " + response);
	            }
	        }).responseJSON;
	   //console.log("Outside: "+ticket_statuses);
	   return ticket_statuses;
}
getSeverityJSONData();
function getSeverityJSONData(){
	   ticket_severities=
		    $.ajax({
		          url: '/webkedb/ticketSeverity',
		          type: 'GET',
		          timeout: 1000,
		          async: false,
		          dataType: 'json',
		            success: function(response) {
		             // console.log("Inside: " + response);
		            }
		        }).responseJSON;
		   //console.log("Outside: "+ticket_severities);
		   return ticket_severities;
}

	//console.log("cat"+category_names+"stats"+ticket_statuses+"severity"+ticket_severities);
/*function setVariables(){

console.log("cat"+category_names+"stats"+ticket_statuses+"severity"+ticket_severities);
setGridDimensions();
}*/

//category_names=["Billing", "Policy", "Claims", "Rating","RATING"];
//var category_dim={"rows": 2, "columns": 3};
	   setCategoryDim();
	   setStatusDim();
	   setSeverityDim();
	   
	function setCategoryDim(){
		var category_names_length=category_names.length;
		category_dim=getGridDimensions(category_names_length);
		//console.log("cat dim"+category_dim);
	}
	
	function setStatusDim(){
		var ticket_statuses_length=ticket_statuses.length;
		status_dim=getGridDimensions(ticket_statuses_length);
		//console.log("stat dim"+status_dim);
		//loop to set ticket_statuses_color to apply legend and generate json on ticket_statuses_color
		for(var i=0;i<ticket_statuses.length;i++){
			if(ticket_statuses[i].toLowerCase()==="open"||ticket_statuses[i].toLowerCase()==="new"){
				ticket_statuses_color.push( ticket_status_color_scale[0]);
			}
			if(ticket_statuses[i].toLowerCase()==="in-progress"||ticket_statuses[i].toLowerCase()==="on-hold"||ticket_statuses[i].toLowerCase()==="pending"){
				ticket_statuses_color.push( ticket_status_color_scale[1]);
			}
			if(ticket_statuses[i].toLowerCase()==="closed"||ticket_statuses[i].toLowerCase()==="resolved"){
				ticket_statuses_color.push( ticket_status_color_scale[2]);
			}
		}
		//console.log("status arr"+ticket_statuses);
		//console.log("color arr"+ticket_status_color_scale)


		//now generating ticketStatusJSON{} assigning key to values
		var obj = {}
		for(var i=0;i<ticket_statuses.length;i++){
			obj[ticket_statuses[i]]=ticket_statuses_color[i];
		}
		ticketStatusJSON=JSON.stringify(obj, null, ' ')
		
		/*million $ solution */
		ticketStatusJSON=JSON.parse(ticketStatusJSON);
		//console.log("status json"+ticketStatusJSON)

	}
	function setSeverityDim(){
		var ticket_severities_length=ticket_severities.length;
		severity_dim=getGridDimensions(ticket_severities_length);
		//console.log("severity dim"+severity_dim);
	}
	
function getGridDimensions(length){
	var len=length;
	//alert(typeof(len));
/*	if(len<=3){return {"rows": 1, "columns": 3};}
	else if(len>=4 || len<=6){return {"rows": 2, "columns": 3};}
	else if(len >=7 || len<=9){return {"rows": 3, "columns": 3};}
	else if(len >=10 || len<=12){return {"rows": 4, "columns": 3};}
	else if(len >=13 || len<=15){return {"rows": 5, "columns": 3};}
	else if(len >=16 || len<=18){return {"rows": 6, "columns": 3};}
	else if(len >=19 || len<=21){return {"rows": 7, "columns": 3};}
	else if(len >=22 || len<=24){return {"rows": 8, "columns": 3}}
	else if(len >=25 || len<=27){return {"rows": 9, "columns": 3}}
	else{return {"rows": 1, "columns": 3};}*/
	switch (true) {
	case len >=1 && len<=3:
		return {"rows": 2, "columns": 3};
		break;
	case len >=4 && len<=6:
		return {"rows": 2, "columns": 3};
		break;
	case len >=7 &&len<=9:
		return {"rows": 3, "columns": 3};
		break;
	case len >=10 &&len<=12:
		return {"rows": 4, "columns": 3};
		break;
	case len >=13 && len<=15:
		return {"rows": 5, "columns": 3};
		break;
	case len >=16 && len<=18:
		return {"rows": 6, "columns": 3};
		break;
	case len >=19 && len<=21:
		return {"rows": 7, "columns": 3};
		break;
	case len >=22 && len<=24:
		return {"rows": 8, "columns": 3};
		break;
	case len >=25 && len<=27:
		return {"rows": 9, "columns": 3};
		break;
	default:
	}
}
var BUBBLE_PARAMETERS = {
    "data_file": "incidents",
    //"report_title": "Largest Cities of the World",
    //"footer_text": "A demonstration of animated bubble charts in JavaScript and D3.js",
    "width": 1200,
    "height": 1000,
    "force_strength": 0.03,
    "force_type": "charge",
    "radius_field": 6,
    //"numeric_fields": ["Area", "Population", "Density"],
    "fill_color": {
        "data_field": "ticket_status",
        "color_groups":ticketStatusJSON
    },
    "tooltip": [
        {"title": "Ticket_Number", "data_field": "ticket_number"},
        {"title": "Severity", "data_field": "ticket_priority"},
        {"title": "Status", "data_field": "ticket_status"}
    ],
    "modes": [
        {
            "button_text": "All Tickets",
            "button_id": "all",
            "type": "grid",
            "labels": null,
            "grid_dimensions": {"rows": 1, "columns": 1},
            "data_field": null
        },
        {
            "button_text": "Categories",
            "button_id": "category_name",
            "type": "grid",
            "labels": category_names,
            "grid_dimensions":category_dim ,
            "data_field": "category_name"
        },
        {
            "button_text": "Severity",
            "button_id": "ticket_priority",
            "type": "grid",
            "labels": ticket_severities,
            "grid_dimensions": severity_dim,
            "data_field": "ticket_priority"
        },
        {
            "button_text": "Status",
            "button_id": "ticket_status",
            "type": "grid",
            "labels": ticket_statuses,
            "grid_dimensions": status_dim,
            "data_field": "ticket_status"
        },        {
            "button_text": "Solution Linked",
            "button_id": "solutionLinked",
            "type": "grid",
            "labels": ["Linked","NotLinked"],
            "grid_dimensions": {"rows": 1, "columns": 2},
            "data_field": "solutionLinked"
        }
    ]
};