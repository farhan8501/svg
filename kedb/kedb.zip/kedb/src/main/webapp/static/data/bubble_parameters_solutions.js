var w = window,
    d = document,
    e = d.documentElement,
    g = d.getElementById('#vis'),
   // x = w.innerWidth || e.clientWidth || g.clientWidth,
    y = w.innerHeight|| e.clientHeight|| g.clientHeight;

var category_names=[];
//var solution_statuses=[];

var category_dim;
//var status_dim;

getCategoryJSONData();
function getCategoryJSONData(){

    category_names=
    $.ajax({
          url: '/webkedb/categories',
          type: 'GET',
          timeout: 1000,
          async: false,
          dataType: 'json',
            success: function(response) {
            //  console.log("Inside: " + response);
            }
        }).responseJSON;
   //console.log("Outside: "+category_names);
   return category_names;		   
}
/*getStatusJSONData();
function getStatusJSONData(){
	solution_statuses=
	    $.ajax({
	          url: '/webkedb/solutionStatus',
	          type: 'GET',
	          timeout: 1000,
	          async: false,
	          dataType: 'json',
	            success: function(response) {
	              //console.log("Inside: " + response);
	            }
	        }).responseJSON;
	   //console.log("Outside: "+ticket_statuses);
	   return solution_statuses;
}*/

	   setCategoryDim();
	   //setStatusDim();
	
	   
	function setCategoryDim(){
		var category_names_length=category_names.length;
		category_dim=getGridDimensions(category_names_length);
		//console.log("cat dim"+category_dim);
	}
/*	
	function setStatusDim(){
		var solution_statuses_length=solution_statuses.length;
		status_dim=getGridDimensions(solution_statuses);
		//console.log("stat dim"+status_dim);
	}*/

	
function getGridDimensions(length){
	var len=length;
	switch (true) {
	case len >=1 && len<=3:
		return {"rows": 1, "columns": 3};
		break;
	case len >=4 && len<=6:
		return {"rows": 2, "columns": 3};
		break;
	case len >=7 &&len<=9:
		return {"rows": 3, "columns": 3};
		break;
	case len >=10 &&len<=12:
		return {"rows": 4, "columns": 3};
		break;
	case len >=13 && len<=15:
		return {"rows": 5, "columns": 3};
		break;
	case len >=16 && len<=18:
		return {"rows": 6, "columns": 3};
		break;
	case len >=19 && len<=21:
		return {"rows": 7, "columns": 3};
		break;
	case len >=22 && len<=24:
		return {"rows": 8, "columns": 3};
		break;
	case len >=25 && len<=27:
		return {"rows": 9, "columns": 3};
		break;
	default:
	}
}

var BUBBLE_PARAMETERS = {
    "data_file": "solution",
    //"report_title": "Largest Cities of the World",
    //"footer_text": "A demonstration of animated bubble charts in JavaScript and D3.js",
    "width": 1200,
    "height": 900,
    "force_strength": 0.03,
    "force_type": "charge",
    "radius_field": 6,
    "fill_color": {
        "data_field": "status",
        "color_groups": {
        	"Created": "#1f77b4",
        	"Rejected": "#d62728",
            "Updated": "#ff7f0e",
			"Approved":"#2ca02c"
        }
    },
    "tooltip": [
        {"title": "Solution_ID", "data_field": "solution_id"},
        {"title": "Search Keyword", "data_field": "search_keyword"},
        {"title": "Status", "data_field": "status"},
		{"title": "Tickets Linked", "data_field": "ticket_count"}
    ],
    "modes": [
        {
            "button_text": "All Solutions",
            "button_id": "all",
            "type": "grid",
            "labels": null,
            "grid_dimensions": {"rows": 1, "columns": 1},
            "data_field": null
        },
        {
            "button_text": "Categories",
            "button_id": "category_name",
            "type": "grid",
            "labels": category_names,
            "grid_dimensions": category_dim,
            "data_field": "category_name"
        },
        {
            "button_text": "Status",
            "button_id": "status",
            "type": "grid",
            "labels": ["Created","Rejected", "Updated","Approved"],
            "grid_dimensions": {"rows": 2, "columns": 3},
            "data_field": "status"
        },        {
            "button_text": "Solution Linked",
            "button_id": "solutionLinked",
            "type": "grid",
            "labels": ["Linked","Not Linked"],
            "grid_dimensions": {"rows": 1, "columns": 2},
            "data_field": "solutionLinked"
        }
    ]
};