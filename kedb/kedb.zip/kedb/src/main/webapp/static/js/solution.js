$(document).ready(function(){
    $('#leftSection').tooltip();   
});
//code for slide menu 1

	function toggleCollapMenu(){
	$("#toolbar a").click(function() {
		var firstKey=this.id;
		switch (true) {
		case firstKey==="category_name":
		$('.secondKey#status,.secondKey#ticket_priority,.secondKey#solutionLinked').removeClass("disable_a_href");
		$('.secondKey#status,.secondKey#ticket_priority,.secondKey#solutionLinked').addClass("enable_bold");
		$('.secondKey#category_name').removeClass("enable_bold");
		$('.secondKey#category_name').addClass("disable_a_href"); 
		$('#item-1 a').addClass("disable_a_href");
		$('#item-3 a').removeClass("disable_a_href");
		$('#item-2 a').removeClass("disable_a_href");
		$('#item-4 a').removeClass("disable_a_href");
			break;
		case firstKey==="status":
			$('.secondKey#category_name,.secondKey#ticket_priority,.secondKey#solutionLinked').removeClass("disable_a_href");
		$('.secondKey#category_name,.secondKey#ticket_priority,.secondKey#solutionLinked').addClass("enable_bold");
		$('.secondKey#status').removeClass("enable_bold");
		$('.secondKey#status').addClass("disable_a_href");
		$('#item-2 a').addClass("disable_a_href");
		$('#item-3 a').removeClass("disable_a_href");
		$('#item-4 a').removeClass("disable_a_href");
		$('#item-1 a').removeClass("disable_a_href");
			break;
		case firstKey==="solutionLinked":
		$('.secondKey#status,.secondKey#ticket_priority,.secondKey#category_name').removeClass("disable_a_href");
		$('.secondKey#status,.secondKey#ticket_priority,.secondKey#category_name').addClass("enable_bold");
		$('.secondKey#solutionLinked').removeClass("enable_bold");
		$('.secondKey#solutionLinked').addClass("disable_a_href");
		$('#item-4 a').addClass("disable_a_href");
		$('#item-3 a').removeClass("disable_a_href");
		$('#item-2 a').removeClass("disable_a_href");
		$('#item-1 a').removeClass("disable_a_href");
			break;
		case firstKey==="all":
			$('.secondKey#status,.secondKey#ticket_priority,.secondKey#solutionLinked,.secondKey#category_name').removeClass("disable_a_href");
			$('.secondKey#status,.secondKey#ticket_priority,.secondKey#solutionLinked,.secondKey#category_name').addClass("enable_bold");
			$('#item-1 a').removeClass("disable_a_href");
			$('#item-3 a').removeClass("disable_a_href");
			$('#item-2 a').removeClass("disable_a_href");
			$('#item-4 a').removeClass("disable_a_href");
				break;
		default:
		$('.secondKey#status,.secondKey#ticket_priority,.secondKey#solutionLinked,.secondKey#category_name').removeClass("disable_a_href");
		$('.secondKey#status,.secondKey#ticket_priority,.secondKey#solutionLinked,.secondKey#category_name').addClass("enable_bold");
		$('#item-1 a').removeClass("disable_a_href");
		$('#item-3 a').removeClass("disable_a_href");
		$('#item-2 a').removeClass("disable_a_href");
		$('#item-4 a').removeClass("disable_a_href");
		}
	})
}
$('a#search_keyword').addClass("enable_bold");
//code for slide menu 
$(document).ready(function () {
    $('#collapsibleMenu3').BootSideMenu({
        side: "right",
        pushBody: true,
        remember: false
    });
    
/*    $('#collapsibleMenu4').BootSideMenu({

    	  // 'left' or 'right'
    	  side: "right",

    	  // animation speed
    	  duration: 500,

    	  // restore last menu status on page refresh
    	  remember: true,

    	  // auto close
    	  autoClose: true,

    	  // push the whole page
    	  pushBody: true,

    	  // close on click
    	  closeOnClick: true,

    	  // width
    	  width: "15%"
    	  
    	});*/
});
$(document).ready(function () {
	$('#collapsibleMenu3').hide().css("visibility", "hidden");
	//$('#collapsibleMenu4').hide().css("visibility", "hidden");
	});
hideRelevantDonut();
//code to hide donut on initial page load
function hideRelevantDonut(){
$('#widget1').hide();
$('#widget2').hide();
$('#widget3').hide();
$('#widget4').hide();
$('#myButton').hide();
}
/*var datasource=[];
//autocomplete ticket number box
$.ajax({
	    type: "GET", 
	    url: '/webkedb/solution',
	    data: "text",
		success:function(response){
			datasource=_.each(response,function(o){
				datasource.push(_.pick(o,'solution_id'));
			});
			console.log(datasource);
			setTicketNumber();
			}
	});
function setTicketNumber() {
	 $('#search').magicsearch({
         dataSource: datasource,
         fields: ['solution_id'],
         id: 'solution_id',
         format: 'solution:%solution_id%',
         focusShow: true
     });
}
*/