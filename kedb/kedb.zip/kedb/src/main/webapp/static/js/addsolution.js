 
$(document).ready(function() {

	$("#selectCategory").change(function() {
    var categoryName = $(this).val(); 
    $.ajax({
        type: "GET",
        url: '/webkedb/subcategories/' + categoryName,
        success: function(data){
            var selectSubcategory=$('#selectSubcategory'), option="";
            selectSubcategory.empty();

            for(var i=0; i<data.length; i++){
                option = option + "<option value='"+data[i]+ "'>"+data[i]+ "</option>";
            }
            selectSubcategory.append(option);
        } 
         
    });
});
 
	var datasource=[];
	var ticket_number;
	var c=1;
	
	//autocomplete ticket number box
	$.ajax({
		    type: "GET", 
		    url: '/webkedb/incidents',
		    data: "text",
			success:function(response){
				datasource=_.each(response,function(o){
					datasource.push(_.pick(o,'ticket_id','ticket_number'));
				});
				//console.log(datasource);
				setTicketNumber();
				}
		});
	function setTicketNumber() {
	$('#basic').magicsearch({
		  dataSource: datasource,
		  fields: ['ticket_id','ticket_number'],
	      multiple: true,
	      focusShow: true,
	      multiField: 'ticket_number',
	      multiStyle: {
	          space: 5,
	          width: 80
	      },
		  id:'ticket_number',
	       success: function($input, data) {
	    	   //var arr = [];
	           ticket_number=   $input.attr('data-id');
	           $.each(ticket_number.split(","), function(i,e){
	        	 var tno=e;  
	            ticket_id = datasource
				.filter(function(d) {
							return d.ticket_number === tno;
						})
				.map(function(d) {
					return d.ticket_id;
				});
	            
	           ticket_id=Object.keys(ticket_id).map(function(k){return ticket_id[k]}).join(",");
	          // arr=arr.push(ticket_id);
	          // console.log(arr);
	       
	           })//each
	           getData(ticket_id);
	          }
	      
		});
	}
	
	var tid;
	function getData(tno){
/*		if(c===1){
			tid=tno;
			c++;
		}
		else{
			tid=+tno;
		}*/
		tid=tno;
	console.log(tid);
	console.log(typeof(tid));
	
    //$("#incident").val(tno);
    $.each(tid.split(","), function(i,e){
        $("#incident option[value='" + e + "']").prop("selected", true);
    });
    //$("#incident").val(tid).trigger("chosen:updated");
	
	/*$('#submitData').click(function() {
		var desc=$('#solution_description').val();
		var keyword=$('#search_keyword').val();
		var category=$('#selectCategory option:selected').text();
		var subCategory=$('#selectSubcategory option:selected').text();
		var ticket_number=tno;
		
	});*/
	}
	/* 	var jsonObj = [];
	
	function createJSON() {
	    
	    $.each(ticket_number,function(i,val) {

	        var key = i;
	        var value = val;

	        item = {}
	        item ["key"] = key;
	        item ["value"] = value;

	        jsonObj.push(item);
	    });

	    console.log(jsonObj); */
});

