/**
 * 
 */

$(document).ready(function() {
	  $('#sub').on('show.bs.collapse', function() {
	    $('#sub .collapse').collapse('hide')
	  })
	});
 