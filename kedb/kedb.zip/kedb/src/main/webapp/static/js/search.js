
  $(document).ready(function(){
    $('input[type=radio][name=option]').click(function(){
        var related_class=$(this).val();
        $('.'+related_class).prop('disabled',false);
        
        $('input[type=radio][name=option]').not(':checked').each(function(){
            var other_class=$(this).val();
            $('.'+other_class).prop('disabled',true);
            
        });
         
    });
  });   
  
    var searchArray = [];
    $.ajax({
  	    type: "GET", 
  	    url: '/webkedb/getallTickets',
  	    data: "text",
  		success:function(response){
  			for (var i = 0; i <response.length - 1; i++) {
  			    searchArray.push( response[i].ticket_number);
  			  
  			}
  			}
  	});
		searchArray = searchArray.sort();
			//console.log(searchArray);
	$(function () {
	    $("#ticket_number").autocomplete({
	    	 maxShowItems: 10,
	        source: searchArray
	    });
	});

	$('#ticket_number').focus(
		    function(){
		        $(this).val('');
		    });
	$('#ticket_desc').focus(
		    function(){
		        $(this).val('');
		    });
	$('#solution_desc').focus(
		    function(){
		        $(this).val('');
		    });
	
	 $('#ticketsearchBtn').click(function() {
	 
	        var id = document.getElementById('ticket_number').value;
	  	    var desc = document.getElementById('ticket_desc').value;
	  	    if (id!==null || id.trim()!==""){
	    	    $.ajax({
	    	    type: "GET", 
	    	    url: '/webkedb/searchticketid/'+id,
	    	    data: "text",
	    		success:function(response){
	    		window.location='/webkedb/search'
	    		}
	    	});
	  	  } 
	  	  
	       if (desc!==null || desc.trim()!==""){
	           	$.ajax({
	        	    type: "GET", 
	        	    url: '/webkedb/searchticketdesc/'+desc,
	        	    data: "text",
	        		success:function(response){
	        		window.location='/webkedb/search'
	        	    }
	        	});
	        }

	     });
	 
	 $('#solutionsearchBtn').click(function() {
		 var desc = document.getElementById('solution_desc').value;
		  if (desc!==null || desc.trim()!==""){
	  	    $.ajax({
	  	    type: "GET", 
	  	    url: '/webkedb/searchsolutiondesc/'+desc,
	  	    data: "text",
	  		success:function(response){
	  		window.location='/webkedb/search'
	  		
	  		}
	  	});
	}
});
	 
	 
	 function createfile(solutionid){
		
		  if (solutionid!==null || solutionid.trim()!==""){
			  
			  $.getJSON('/webkedb/searchsolutionattachment/'+solutionid, function(data){ 
	  			
	  			$.each(data, function (key, value) {
	  				var filename =JSON.stringify(value.name);
	  				var fileid = JSON.stringify(value.id);
	  				
	  				$("#"+solutionid).append('<a href="/webkedb/download-solutionfile- '+solutionid+' - '+fileid+'">'+filename+'</a>');
	  				
	  				$("#"+solutionid).append($("<p>"));
	  			    	
	  			    $("#btn"+solutionid).hide();
	  			    	 
	  			});
			  });
		  }
		   
	 }

  
  
  
  
  
   