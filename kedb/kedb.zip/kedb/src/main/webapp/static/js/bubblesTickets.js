/* Bubble chart
 * 
 * Based on Jim Vallandingham's work
 * Organization and style inspired by:
 * https://bost.ocks.org/mike/chart/
 *
 */
$(document).ready(function () {
	$('#collapsibleMenu1').hide().css("visibility", "hidden");
	$('#collapsibleMenu2').hide().css("visibility", "hidden");
	});  
var searchArray = [];
var svg = null, inner_svg = null;
  var rSwitch;
  var firstKey="";
  var secondKeyName = "";
  var secondValueName = "";
  var filteredData;
  var fillStatusColor = d3.scaleOrdinal()
  .domain(ticket_statuses)
  .range(ticket_statuses_color);
  var ticket_id;
  //var categoryNames;
function createBubbleChart() {
    /* bubbleChart creation function. Returns a function that will
     * instantiate a new bubble chart given a DOM element to display
     * it in and a dataset to visualize.
     */

    // Tooltip object for mouseover functionality, width 200
    var tooltip = floatingTooltip('bubble_chart_tooltip', 200);
    // These will be set in the `bubbleChart` function
   
    var bubbles = null;
    var forceSim = null;
    var fillColorScale = null;
    var radiusScale = null;
    var nodes = [];
    var margin = null;
    var width = null;
    var height = null;
    var dataExtents = {};

  


/*    // For scatterplots (initialized if applicable)
    var xAxis = null;
    var yAxis = null;
    var xScale = null;
    var yScale = null;
    // For the map
    var bubbleMercProjection = d3.geoMercator()
        .rotate([-180, 0]);*/

    function getFillColorScale() {
        // Obtain a color mapping from keys to color values specified in our parameters file

        // Get the keys and values from the parameters file
        var color_groupsKeys = Object.keys(BUBBLE_PARAMETERS.fill_color.color_groups)
        var color_groupsValues = []
        for (var i=0; i<color_groupsKeys.length; i++) {
            var key = color_groupsKeys[i]
            color_groupsValues.push(BUBBLE_PARAMETERS.fill_color.color_groups[key])
        }
        
        // Generate the key -> value mapping for colors
        var fillColorScale = d3.scaleOrdinal()
            .domain(color_groupsKeys)
            .range(color_groupsValues);

        return fillColorScale;
    }
    
    function createNodes(rawData) {
        /*
         * This data manipulation function takes the raw data from
         * the CSV file and converts it into an array of node objects.
         * Each node will store data and visualization values to visualize
         * a bubble.
         *
         * rawData is expected to be an array of data objects, read in from
         * one of d3's loading functions like d3.csv.
         *
         * This function returns the new node array, with a node in that
         * array for each element in the rawData input.
         */
        // Use map() to convert raw data into node data.
        var myNodes = rawData.map(function (data_row) {
            node = {
                id: data_row.id,
               scaled_radius: rSwitch/*radiusScale(+data_row[BUBBLE_PARAMETERS.radius_field])*/,
                actual_radius: rSwitch/*data_row[BUBBLE_PARAMETERS.radius_field]*/,
                fill_color_group: data_row[BUBBLE_PARAMETERS.fill_color.data_field],
                // Put each node initially in a random location
                x: (Math.random()*0.1) * width,
                y: (Math.random()*0.1) * height
            };
            for(var key in data_row) {
                // Skip loop if the property is from prototype
                if (!data_row.hasOwnProperty(key)) continue;
                node[key] = data_row[key];
            }
            
            return node;
        });

        // Sort them to prevent occlusion of smaller nodes.
       myNodes.sort(function (a, b) { return b.actual_radius - a.actual_radius; });

        return myNodes;
    }

    function getGridTargetFunction(mode) {
        // Given a mode, return an anonymous function that maps nodes to target coordinates
        if (mode.type != "grid") {
            throw "Error: getGridTargetFunction called with mode != 'grid'";
        }
        return function (node) {
            // Given a mode and node, return the correct target
            if(mode.size == 1) {
                // If there is no grid, our target is the default center
                target = mode.gridCenters[""];
            } else {
                // If the grid size is greater than 1, look up the appropriate target
                // coordinate using the relevant node_tag for the mode we are in
                node_tag = node[mode.dataField]
                target = mode.gridCenters[node_tag];
            }
            return target;
        }
    }
    
    function showLabels(mode) {
        /*
         * Shows labels for each of the positions in the grid.
         */
        var currentLabels = mode.labels; 
        var bubble_group_labels = inner_svg.selectAll('.bubble_group_label')
            .data(currentLabels);

        var grid_element_half_height = height / (mode.gridDimensions.rows * 2);
            
        bubble_group_labels.enter().append('text')
            .attr('class', 'bubble_group_label')
            .attr('x', function (d) { return mode.gridCenters[d].x; })
            .attr('y', function (d) { return mode.gridCenters[d].y - grid_element_half_height; })
            .attr('text-anchor', 'middle')                // centre the text
            .attr('dominant-baseline', 'hanging') // so the text is immediately below the bounding box, rather than above
            .text(function (d) { return d; });

        // GRIDLINES FOR DEBUGGING PURPOSES
        /*
        var grid_element_half_height = height / (mode.gridDimensions.rows * 2);
        var grid_element_half_width = width / (mode.gridDimensions.columns * 2);
        
        for (var key in currentMode.gridCenters) {
            if (currentMode.gridCenters.hasOwnProperty(key)) {
                var rectangle = inner_svg.append("rect")
                    .attr("class", "mc_debug")
                    .attr("x", currentMode.gridCenters[key].x - grid_element_half_width)
                    .attr("y", currentMode.gridCenters[key].y - grid_element_half_height)
                    .attr("width", grid_element_half_width*2)
                    .attr("height", grid_element_half_height*2)
                    .attr("stroke", "red")
                    .attr("fill", "none");
                var ellipse = inner_svg.append("ellipse")
                    .attr("class", "mc_debug")
                    .attr("cx", currentMode.gridCenters[key].x)
                    .attr("cy", currentMode.gridCenters[key].y)
                    .attr("rx", 15)
                    .attr("ry", 10);
            }
        }*/
    }

    function tooltipContent(d) {
        /*
         * Helper function to generate the tooltip content
         * 
         * Parameters: d, a dict from the node
         * Returns: a string representing the formatted HTML to display
         */
        var content = ''

        // Loop through all lines we want displayed in the tooltip
        for(var i=0; i<BUBBLE_PARAMETERS.tooltip.length; i++) {
            var cur_tooltip = BUBBLE_PARAMETERS.tooltip[i];
            var value_formatted;

            // If a format was specified, use it
            if ("format_string" in cur_tooltip) {
                value_formatted = 
                    d3.format(cur_tooltip.format_string)(d[cur_tooltip.data_field]);
            } else {
                value_formatted = d[cur_tooltip.data_field];
            }
            
            // If there was a previous tooltip line, add a newline separator
            if (i > 0) {
                content += '<br/>';
            }
            content += '<span class="name">'  + cur_tooltip.title + ': </span>';
            content += '<span class="value">' + value_formatted     + '</span>';
        }        

        return content;
    }

    function showTooltip(d) {
        /*
         * Function called on mouseover to display the
         * details of a bubble in the tooltip.
         */
        // Change the circle's outline to indicate hover state.
        d3.select(this).attr('stroke', 'black');

        // Show the tooltip
        tooltip.showTooltip(tooltipContent(d), d3.event);
    }

    function hideTooltip(d) {
        /*
         * Hide tooltip
         */
        // Reset the circle's outline back to its original color.
        var originalColor = d3.rgb(fillColorScale(d.fill_color_group)).darker()
        d3.select(this).attr('stroke', originalColor);

        // Hide the tooltip
        tooltip.hideTooltip();
    }

    function ticked() {
        bubbles.each(function (node) {})
            .attr("cx", function(d) { return d.x; })
            .attr("cy", function(d) { return d.y; });
    }

/*    function showAxis(mode) {
        
         *  Show the axes.
         

        // Set up axes
        xAxis = xScale; //d3.scaleBand().rangeRound([0, width]).padding(0.1);
        yAxis = yScale; //d3.scaleLinear().rangeRound([height, 0]);  

        inner_svg.append("g")
            .attr("class", "axis axis--x")
            .attr("transform", "translate(0," + height + ")")
            .call(d3.axisBottom(xAxis))
        inner_svg.append("text")
            .attr("class", "axis axis--x label")
            .attr("transform", "translate(" + (width/2) + " , " + (height) + ")")
            // so the text is immediately below the bounding box, rather than above
            .attr('dominant-baseline', 'hanging')
            .attr("dy", "1.5em")
            .style("text-anchor", "middle")
            .text(mode.xDataField);

        inner_svg.append("g")
            .attr("class", "axis axis--y")
            .call(d3.axisLeft(yAxis).ticks(10))//, "%"))
        
        inner_svg.append("text")
            .attr("class", "axis axis--y label")
            // We need to compose a rotation with a translation to place the y-axis label
            .attr("transform", "translate(" + 0 + ", " + (height/2) + ")rotate(-90)")
            .attr("dy", "-3em")
            .attr("text-anchor", "middle")
            .text(mode.yDataField);
    }*/

    function createBubbles() {
        // Bind nodes data to what will become DOM elements to represent them.
        inner_svg.selectAll('.bubble')
            .data(nodes, function (d) { return d.ticket_id; })
            // Create new circle elements each with class `bubble`.
            // There will be one circle.bubble for each object in the nodes array.
           .enter()
            .append('circle').attr('r', 0)
            // Initially, their radius (r attribute) will be 0.
            .attr("ticket_id", function(d) {return d.ticket_id;})
            .attr("id", function(d) {return d.ticket_number;})
            .classed('bubble', true)
            .attr('fill', function (d) {return fillColorScale(d.fill_color_group); })
            .attr('stroke', function (d) { return d3.rgb(fillColorScale(d.fill_color_group)).darker(); })
            .attr('stroke-width', 2)
            .on('mouseover', showTooltip)
            .on('mouseout', hideTooltip);

        bubbles = d3.selectAll('.bubble');
        legendStatus();
        // Fancy transition to make bubbles appear, ending with the correct radius
        bubbles.transition()
            .duration(10)
            .attr('r', function (d) { return d.scaled_radius; });
        makeClickable();
    }
    function legendStatus(){
    	
    	svg.selectAll(".legend").remove();
    	  var svgLegned = inner_svg.append("g")
          .attr("class", ".legend");
          
      //D3 Vertical Legend//////////////////////////
      var legend = svgLegned.selectAll('.legend')
          .data(fillStatusColor.domain())
          .enter().append('g')
          .attr("class", "legends")
          .attr("transform", function (d, i) {
          {
              return "translate(0," + ((i * 20)+10)+ ")"
          }
      })
      
      legend.append('rect')
          .attr("x", 0)
          .attr("y", 0)
          .attr("width", 10)
          .attr("height", 10)
          .style("fill", fillStatusColor)
      
      legend.append('text')
          .attr("x", 20)
          .attr("y", 10)
      //.attr("dy", ".35em")
      .text(function (d, i) {
          return d
      })
          .attr("class", "textselected")
          .style("text-anchor", "start")
          .style("font-size", 15)
    }
    function addForceLayout(isStatic) {
        if (forceSim) {
            // Stop any forces currently in progress
            forceSim.stop();
        }
        // Configure the force layout holding the bubbles apart
        forceSim = d3.forceSimulation()
            .nodes(nodes)
            .velocityDecay(0.3)
            .on("tick", ticked);
        
        if (!isStatic) {
            // Decide what kind of force layout to use: "collide" or "charge"
            if(BUBBLE_PARAMETERS.force_type == "collide") {
                var bubbleCollideForce = d3.forceCollide()
                    .radius(function(d) { return d.scaled_radius + 0.5; })
                    .iterations(4)
                forceSim
                    .force("collide", bubbleCollideForce)
            }
            if(BUBBLE_PARAMETERS.force_type == "charge") {
                function bubbleCharge(d) {
                    return -Math.pow(d.scaled_radius, 2.0) * (+BUBBLE_PARAMETERS.force_strength);
                }    
                forceSim
                    .force('charge', d3.forceManyBody().strength(bubbleCharge));
            }
        }
    }

    function createCanvas(parentDOMElement) {
        // Create a SVG element inside the provided selector with desired size.
        svg = d3.select(parentDOMElement)
            .append('svg')
            .attr('width', BUBBLE_PARAMETERS.width)
            .attr('height', BUBBLE_PARAMETERS.height)
            .attr("id","bubbleSVG");

        // Specify margins and the inner width and height
       // margin = {top: 20, right: 20, bottom: 50, left: 80},
        width = +svg.attr("width"),
        height = +svg.attr("height");

        // Create an inner SVG panel with padding on all sides for axes
        inner_svg = svg.append("g")
            .attr("transform", "translate(" + 0 + "," + 0 + ")");        
    }    
    //////////////////////////////////////////////////////////////
    
    var bubbleChart = function bubbleChart(parentDOMElement, rawData) {
        /*
         * Main entry point to the bubble chart. This function is returned
         * by the parent closure. It prepares the rawData for visualization
         * and adds an svg element to the provided selector and starts the
         * visualization creation process.
         *
         * parentDOMElement is expected to be a DOM element or CSS selector that
         * points to the parent element of the bubble chart. Inside this
         * element, the code will add the SVG continer for the visualization.
         *
         * rawData is expected to be an array of data objects as provided by
         * a d3 loading function like d3.csv.
         */
        
        // Capture all the maximums and minimums in the numeric fields, which
        // will be used in any scatterplots.
/*        for (var numeric_field_index in BUBBLE_PARAMETERS.numeric_fields) {
            var numeric_field = BUBBLE_PARAMETERS.numeric_fields[numeric_field_index];
            dataExtents[numeric_field] = d3.extent(rawData, function (d) { return +d[numeric_field]; });
        }*/
        // Scale bubble radii using ^(0.5)
        // We size bubbles based on area instead of radius
        var maxRadius = BUBBLE_PARAMETERS.radius_field;
        radiusScale = d3.scalePow()
            .exponent(0.5)
            .range([2, 25])  // Range between 2 and 25 pixels
            .domain([0, maxRadius]);   // Domain between 0 and the largest bubble radius

        fillColorScale = getFillColorScale();
        
        // Initialize the "nodes" with the data we've loaded
        nodes = createNodes(rawData);

        // Initialize svg and inner_svg, which we will attach all our drawing objects to.
        createCanvas(parentDOMElement);

        // Create a container for the map before creating the bubbles
        // Then we will draw the map inside this container, so it will appear behind the bubbles
/*        inner_svg.append("g")
            .attr("class", "world_map_container");*/
        
        // Create the bubbles and the force holding them apart
        createBubbles();
    };

    bubbleChart.switchMode = function (buttonID) {
        /*
         * Externally accessible function (this is attached to the
         * returned chart function). Allows the visualization to toggle
         * between display modes.
         *
         * buttonID is expected to be a string corresponding to one of the modes.
         */
        // Get data on the new mode we have just switched to
        currentMode = new ViewMode(buttonID, width, height);

        // Remove current labels
        inner_svg.selectAll('.bubble_group_label').remove();
        // Remove current debugging elements
        inner_svg.selectAll('.mc_debug').remove(); // DEBUG
        // Remove axes components
/*        inner_svg.selectAll('.axis').remove();
        // Remove map
        inner_svg.selectAll('.world_map').remove();*/

        // SHOW LABELS (if we have more than one category to label)
        if (currentMode.type == "grid" && currentMode.size > 1) {
            showLabels(currentMode);
        }

/*        // SHOW AXIS (if our mode is scatter plot)
        if (currentMode.type == "scatterplot") {
            xScale = d3.scaleLog().range([0, width])
                .domain([dataExtents[currentMode.xDataField][0], dataExtents[currentMode.xDataField][1]]);
            yScale = d3.scaleLog().range([height, 0])
                .domain([dataExtents[currentMode.yDataField][0], dataExtents[currentMode.yDataField][1]]);
            
            showAxis(currentMode);
        }*/
/*        // ADD FORCE LAYOUT
        if (currentMode.type == "scatterplot" || currentMode.type == "map") {
            addForceLayout(true);  // make it static so we can plot bubbles
        } else {*/
            addForceLayout(false); // the bubbles should repel about the grid centers
      //  }

/*        // SHOW MAP (if our mode is "map")
        if (currentMode.type == "map") {
            var path = d3.geoPath().projection(bubbleMercProjection);

            d3.queue()
                .defer(d3.json, "data/world-110m2.json")
                .await(ready);

                function ready(error, topology) {
                  if (error) throw error;

                  inner_svg.selectAll(".world_map_container")
                    .append("g")
                    .attr("class", "world_map")
                    .selectAll("path")
                    .data(topojson.feature(topology, topology.objects.countries).features)
                    .enter()
                    .append("path")
                    .attr("d", path);
                }
        }*/
        
        // MOVE BUBBLES TO THEIR NEW LOCATIONS
        var targetFunction;
        if (currentMode.type == "grid") {
            targetFunction = getGridTargetFunction(currentMode);
        }
/*        if (currentMode.type == "scatterplot") {
            targetFunction = function (d) {
                return { 
                    x: xScale(d[currentMode.xDataField]),
                    y: yScale(d[currentMode.yDataField])
                };
            };
        }
        if (currentMode.type == "map") {
            targetFunction = function (d) {
                return {
                    x: bubbleMercProjection([+d.Longitude, +d.Latitude])[0],
                    y: bubbleMercProjection([+d.Longitude, +d.Latitude])[1]
                };
            };
        }*/
        
        // Given the mode we are in, obtain the node -> target mapping
        var targetForceX = d3.forceX(function(d) {return targetFunction(d).x})
            .strength(+BUBBLE_PARAMETERS.force_strength);
        var targetForceY = d3.forceY(function(d) {return targetFunction(d).y})
            .strength(+BUBBLE_PARAMETERS.force_strength);

        // Specify the target of the force layout for each of the circles
        forceSim
            .force("x", targetForceX)
            .force("y", targetForceY);

        // Restart the force layout simulation
        forceSim.alphaTarget(1).restart();
    };
    
    					function makeClickable() {
    						$("circle").dblclick(
    								function() {
    									window.location.href = "/webkedb/ticket-"
    											+ ticket_id;
    								});

    						$("circle").click(function() {
    											/*
    											 * write code to enable the relevant
    											 * box
    											 */
    										//	document.getElementById("container").style.visibility = "visible";
    							//fade background bubbles
    							//node1.classed('selected', false).attr("r",rSwitch).style("opacity","0.6");
    							$("circle").css("opacity",0.6);
    					    	//highlight current bubble
    					    	d3.select(this).attr("r",rSwitch+5).style("opacity",1)
    					         
    											document.getElementById("incident").innerHTML = "Ticket_Number: "+ (this.id);
    											//function call to hide donut when no relevant results
    											hideRelevantDonut();

    											var ticket_number = this.id;
/*    											ticket_id = data
    													.filter(function(d) {
    																return d.ticket_number === ticket_number;
    															})
    													.map(function(d) {
    														return d.ticket_id;
    													});*/
    											ticket_id=jQuery(this).attr("ticket_id");
    											$.getJSON('/webkedb/releavancesearchjson/'+ this.id,function(data) {
    														dataRelevance = data;
    														getRelevantData();
    													});
    											/* $('html,body').animate({
    											        scrollTop: $("#incident").offset().top},
    											        500);*/
    											
    										});

    					}//end of makeClickable
   // Return the bubbleChart function from closure.
   return bubbleChart;//end of createBubbleChart()
    					
}//create bubble chart where json data rests

/////////////////////////////////////////////////////////////////////////////////////
function ViewMode(button_id, width, height) {
    /* ViewMode: an object that has useful parameters for each view mode.
     * initialize it with your desired view mode, then use its parameters.
     * Attributes:
     - mode_index (which button was pressed)
     - buttonId     (which button was pressed)
     - gridDimensions    e.g. {"rows": 10, "columns": 20}
     - gridCenters       e.g. {"group1": {"x": 10, "y": 20}, ...}
     - dataField    (string)
     - labels       (an array)
     - type         (type of grouping: "grouping" or "scatterplot")
     - size         (number of groups)
     */
    // Find which button was pressed
    var mode_index;
    for(mode_index=0; mode_index<BUBBLE_PARAMETERS.modes.length; mode_index++) {
        if(BUBBLE_PARAMETERS.modes[mode_index].button_id == button_id) {
            break;
        }
    }
    if(mode_index>=BUBBLE_PARAMETERS.modes.length) {
        console.log("Error: can't find mode with button_id = ", button_id)
    }
    
    var curMode = BUBBLE_PARAMETERS.modes[mode_index];
    this.buttonId = curMode.button_id;
    this.type = curMode.type;
    
    if (this.type == "grid") {
        this.gridDimensions = curMode.grid_dimensions;
        this.labels = curMode.labels;
        if (this.labels == null) { this.labels = [""]; }
        this.dataField = curMode.data_field;
        this.size = this.labels.length;
        // Loop through all grid labels and assign the centre coordinates
        this.gridCenters = {};
        for(var i=0; i<this.size; i++) {
            var cur_row = Math.floor(i / this.gridDimensions.columns);    // indexed starting at zero
            var cur_col = i % this.gridDimensions.columns;    // indexed starting at zero
            var currentCenter = {
                x: (2 * cur_col + 1) * (width / (this.gridDimensions.columns * 2)),
                y: (2 * cur_row + 1) * (height / (this.gridDimensions.rows * 2))
            };
            this.gridCenters[this.labels[i]] = currentCenter;
        }
    }
/*    if (this.type == "scatterplot") {
        // Set up the x and y scales (domains need to be set using the actual data)
        this.xDataField = curMode.x_data_field;
        this.yDataField = curMode.y_data_field;
        this.xFormatString = curMode.x_format_string;
        this.yFormatString = curMode.y_format_string;
    }
    if (this.type == "map") {
        this.latitudeField = curMode.latitude_field;
        this.longitudeField = curMode.longitude_field;
    }*/
};


// Create a new bubble chart instance
var myBubbleChart = createBubbleChart();

/*changeDataSource('master');
	
function changeDataSource(data){
	
	if (data === 'master'){*/
		//send master data
		// Load data
		d3.json("/webkedb/"+ BUBBLE_PARAMETERS.data_file, function (error, data) {
			if (error) { console.log(error); }
			//console.log(data.length);
		
			
			/**************************************************************/
		//key-> values from incidents controller
			var categoryNames = _.keys(_.countBy(data, function(d){
			    return d.category_name;
			}));
			category_names_l=category_names.map(function(x){ return x.toLowerCase() })
			categoryNames_l=categoryNames.map(function(x){ return x.toLowerCase() })
			//var weirdCategoriesEntries=category_names.filter(function(obj) { return categoryNames.indexOf(obj) == -1; });
			var weirdCategoriesEntries = _.difference(categoryNames_l, category_names_l).concat(_.difference(category_names_l, categoryNames_l));

			//console.log("weird cate"+weirdCategoriesEntries);
			 //console.log("values of categories from json ")
			//console.log(categoryNames);
			// console.log("values from built table")
			//console.log(category_names)
			
			for(var i=0;i<category_names.length;i++){
				for(var j=0;j<categoryNames.length;j++){
					/*if(category_names[i]===categoryNames[j]){
						//console.log("case sensitive:"+category_names[i],categoryNames[j])}
					}*/
					if(category_names[i].toLowerCase()===categoryNames[j].toLowerCase()){
					//	console.log("case in sensitive:"+category_names[i],categoryNames[j])
					for(var k=0;k<data.length;k++){
						if(data[k].category_name===categoryNames[j])
							{
							data[k].category_name=category_names[i];
							}
					}//for	
					
					}//else if
					
				}//for
			}//for
			//remove weird json objects that do not match from built in table
			for(var l=0;l<data.length;l++){
				data=data.filter(function(item) { 
					   return item.category_name !=weirdCategoriesEntries[l]; 
				});
			}
			
			 /**************************************************************/
			//key-> values from incidents controller
			var statusNames = _.keys(_.countBy(data, function(d){
			    return d.ticket_status;
			}));
			 //console.log("values of statusNames from json ")
			//console.log(statusNames);
			// console.log("values from built table")
			//console.log(category_names)
			ticket_statuses_l=ticket_statuses.map(function(x){ return x.toLowerCase() })
			statusNames_l=statusNames.map(function(x){ return x.toLowerCase() })
			var weirdStatusEntries=_.difference(statusNames_l, ticket_statuses_l).concat(_.difference(ticket_statuses_l, statusNames_l));
			for(var i=0;i<ticket_statuses.length;i++){
				for(var j=0;j<statusNames.length;j++){
					/*if(ticket_statuses[i]===statusNames[j]){
						//console.log("case sensitive:"+category_names[i],categoryNames[j])}
					}*/
					if(ticket_statuses[i].toLowerCase()===statusNames[j].toLowerCase()){
						//console.log("case in sensitive:"+category_names[i],categoryNames[j])
					for(var k=0;k<data.length;k++){
						if(data[k].ticket_status===statusNames[j])
							{
							data[k].ticket_status=ticket_statuses[i];
							}
					}//for	
					
					}//if
				}//for
			}//for
			//remove weird json objects that do not match from built in table
			for(var l=0;l<data.length;l++){
				data=data.filter(function(item) { 
					   return item.ticket_status.toLowerCase() !=weirdStatusEntries[l]; 
				});
			}
			 /**************************************************************/
			//key-> values from incidents controller
			var severityNames = _.keys(_.countBy(data, function(d){
			    return d.ticket_priority;
			}));
			 //console.log("values of categories from json ")
			//console.log(categoryNames);
			// console.log("values from built table")
			//console.log(category_names)
			ticket_severities_l=ticket_severities.map(function(x){ return x.toLowerCase() })
			severityNames_l=severityNames.map(function(x){ return x.toLowerCase() })
			var weirdSeverityEntries=_.difference(severityNames_l, ticket_severities_l).concat(_.difference(ticket_severities_l, severityNames_l));
			for(var i=0;i<ticket_severities.length;i++){
				for(var j=0;j<severityNames.length;j++){
					/*if(ticket_severities[i]===severityNames[j]){
						//console.log("case sensitive:"+category_names[i],categoryNames[j])}
					}*/
					if(ticket_severities[i].toLowerCase()===severityNames[j].toLowerCase()){
						//console.log("case in sensitive:"+category_names[i],categoryNames[j])
					for(var k=0;k<data.length;k++){
						if(data[k].ticket_priority===severityNames[j])
							{
							data[k].ticket_priority=ticket_severities[i];
							}
					}//for	
					
					}//if
				}//for
			}//for
			//console.log("weird ticket severity:"+weirdSeverityEntries)
			//remove weird json objects that do not match from built in table
			for(var l=0;l<data.length;l++){
				data=data.filter(function(item) { 
					   return item.ticket_priority.toLowerCase() !=weirdSeverityEntries[l]; 
				});
			}
			 /**************************************************************/
		    

			 // Once the data is loaded...
			total_tickets = _.size(data);
			document.getElementById("total_tickets").innerHTML = total_tickets;

			//console.log(statusNames);
			for(var i=0;i<statusNames.length;i++){
				if(statusNames[i].toLowerCase()==="open"||statusNames[i].toLowerCase()==="new"){
					if(statusNames[i].toLowerCase()==="open"){
						ticket_open = _.size(_.filter(data, function(d) {
							return d.ticket_status.toLowerCase() === "open";
						}));
						
						document.getElementById("ticket_open").innerHTML = ticket_open;
					}
					else{
						ticket_open = _.size(_.filter(data, function(d) {
							return d.ticket_status.toLowerCase() === "new";
						}));
						
						document.getElementById("ticket_open").innerHTML = ticket_open;
					}
				}
				else if(statusNames[i].toLowerCase()==="closed"||statusNames[i].toLowerCase()==="resolved"){
					if(statusNames[i].toLowerCase()==="closed"){
						ticket_closed = _.size(_.filter(data, function(d) {
							return d.ticket_status.toLowerCase() === "closed";
						}));
						
						document.getElementById("ticket_closed").innerHTML = ticket_closed;
					}
					else{
						ticket_closed = _.size(_.filter(data, function(d) {
							return d.ticket_status.toLowerCase() === "resolved";
						}));
						
						document.getElementById("ticket_closed").innerHTML = ticket_closed;
					}
				}
			}
			
			for(var i=0;i<severityNames.length;i++){
				if(severityNames[i].toLowerCase()==="high"||severityNames[i].toLowerCase()==="severe"){
					if(severityNames[i].toLowerCase()==="high"){
						ticket_highSeverity = _.size(_.filter(data, function(d) {
							return d.ticket_priority.toLowerCase() === "high";
						}));
						document.getElementById("ticket_highSeverity").innerHTML = ticket_highSeverity;
					}
					else{
						ticket_highSeverity = _.size(_.filter(data, function(d) {
							return d.ticket_priority.toLowerCase() === "severe";
						}));
						
						document.getElementById("ticket_highSeverity").innerHTML = ticket_highSeverity;
					}
				}
			}


/*			ticket_highSeverity = _.size(_.filter(data, function(d) {
				return d.ticket_priority.toLowerCase() === "high";
			}));
			document.getElementById("ticket_highSeverity").innerHTML = ticket_highSeverity;*/

			ticekts_linked = _.size(_.filter(data, function(d) {
				return d.solutionLinked.toLowerCase() === "linked";
			}));
			document.getElementById("ticekts_linked").innerHTML = ticekts_linked;
		    
			
		    
		 // alert(data.length); //to get json data length
			//console.log(data);
			var length = data.length;

			switch (true) {
			case length < 200:
				rSwitch = 15;
				break;
			case length <= 200 && length < 500:
				rSwitch = 13;
				break;
			case length <= 500 && length < 1000:
				rSwitch = 12;
				break;
			case length <= 1000 && length < 2000:
				rSwitch = 10;
				break;
			case length <= 2000 && length < 5000:
				rSwitch = 8;
				break;
			case length <= 5000 && length < 10000:
				rSwitch = 5;
				break;
			case length >= 10000:
				rSwitch = 4;
				break;
			default:
			}
		    
		    
		    //get all ticket number in an array

			for (var i = 0; i <data.length - 1; i++) {
			    searchArray.push( data[i].ticket_number);
			  
			}
			searchArray = searchArray.sort();
			//console.log(optArray+"ticket_number from optArray");
			
			//placeholder for search box

			$('#search').focus(
				    function(){
				        $(this).val('');
				    });
			$('input[name="search]').on('change', function() {
			    $(this).valid();  // trigger validation test
			});
			$(function () {
			    $("#search").autocomplete({
			    	 maxShowItems: 10,
			        source: searchArray,
			        change: function(event,ui)
			        {
			        if (ui.item==null)
			            {
			            $("#search").val('');
			            $("#search").focus();
			           // $("#search").parent().after("<div class='validation' style='color:red;margin-bottom: 20px;'>Please enter valid Ticket Number</div>");
			            alert("please select the ticket number from auto suggestions \n If not found please search in SEARCH page)");
			            
			            }
			        else{
			        	searchTicket();
			        }
			        }

			    });
			});

			function searchTicket(){
			//$( "#search" ).autocomplete("widget").addClass("scrollFixedHeight");
			$("#searchButton").click(function(){
				
			    //find the node
			    var selectedVal = document.getElementById('search').value;
			   
			    console.log("selected value from the search box:"+selectedVal);
			    var node = inner_svg.selectAll("circle");
			    if (selectedVal == "none") {
			        node.style("stroke", "white").style("stroke-width", "1");
			    } else{
			    	//returns all the other bubbles except searched
			        var selected = node.filter(function (d, i) {
			            return d.ticket_number != selectedVal;
		/*						        node.on("click", function(d) {
				        	node.classed('selected', false);
				        	d3.select(this).classed('selected', true)
				    	});*/
			        });
			        
			        //reset bubble attr
			        $("circle").css("opacity",0.6).attr("r",rSwitch);
			        //returns bubble which was searched
			   var  selectedBubble=node.filter(function(d,i){return d.ticket_number==selectedVal;})
			       // console.log("selected node value:"+selected);
			        selected.style("opacity", "0.6");
			        //selected.classed("selected",false);
			        
			   //nodes.classed('selected', false).attr("r",rSwitch).style("opacity","0.6");
			   $("circle").css("opacity",0.6);
			   
			   selectedBubble
		        .attr("r",rSwitch+5).style("opacity",1);
			   /*selectedBubble.classed("selected",true)
			        .attr("r",rSwitch+2).style("opacity",1);*/
			    
			        d3.selectAll("circle").transition()
			            .duration(50);
			            /*.style("opacity", 1);*/
			        
			        document.getElementById("incident").innerHTML = "Ticket_Number: "+ selectedVal;
			   
			        $.getJSON('/webkedb/releavancesearchjson/'+ selectedVal,function(data) {
						dataRelevance = data;
						getRelevantData();
					});
			        
			        //auto scroll towards relevant donuts
			        $('html,body').animate({
				        scrollTop: $("#incident").offset().top},
				        500);
			        //$('#search').val('');
			    }
			    
			});//end of search
			
			}
		    // Display bubble chart inside the #vis div.
		    myBubbleChart('#vis', data);

		    // Start the visualization with the first button
		    myBubbleChart.switchMode(BUBBLE_PARAMETERS.modes[0].button_id)
		
		var callCount = 1;

		$(document).ready(function() {
		$("#toolbar a").click(function() {
			
			// $('a#ticket_status,a#ticket_priority,a#solutionLinked,a#category_name').removeClass("disable_a_href");
			$('#collapsibleMenu1').show().css("visibility", "visible");
			hideRelevantDonut();
			firstKey=this.id;
			
			//console.log("level 1 filter name"+firstKey);
			//if it is a first call then filter on master data
			if(callCount==1){
				level1=document.getElementById("breadcrumb").innerHTML="Filtered On:"+this.id;

			$('a.secondKey').click(function() {
				
				hideRelevantDonut();
				$("circle").css("opacity",1).attr("r",rSwitch);
			//$('#collapsibleMenu2').hide();
			secondKeyName = this.id;
			$('a.secondValue').click(function() {
				callCount=2;
				
				
			//$('#collapsibleMenu2').show().css("visibility", "visible");;
			secondValueName = this.id;
			
			//remove legend when call retraces from L3 to L2

				//svg.selectAll(".legend").remove();
			
			document.getElementById("breadcrumb").innerHTML=level1+">>"+secondKeyName+"("+secondValueName+")";
				if (secondKeyName == "category_name") {
					filteredData = _.filter(data,function(d) {
					return d.category_name == secondValueName;})
				} else if (secondKeyName == "ticket_status") {
					filteredData = _.filter(data,function(d) {
					return d.ticket_status == secondValueName;})
				} else if (secondKeyName == "ticket_priority") {
					filteredData = _.filter(data,function(d) {
					return d.ticket_priority == secondValueName;})
				} else if (secondKeyName == "solutionLinked") {
					filteredData = _.filter(data,function(d) {
					return d.solutionLinked == secondValueName;})
				} else {
					console.log("not able to filter the data based on side menu clicked");
				}
				//changeDataSource('filter');
/*				console.log("filter bubble to generate");
				console.log(filteredData);*/
/*			    // Display bubble chart inside the #vis div.
			    myBubbleChart('#vis', filteredData);*/
				generateFilteredData();

		})
		})//end of secondKey

		}//callCount monitoring
			//if it is a second call reload the bubble.js
			else{
				$('label[id*="breadcrumb"]').text('');
				
			    function reload_js(src) {
			    	//$(".radioClass:checked").removeAttr("checked");
			    	$('svg[id="primarySVG"]').remove();
			        $('script[src="' + src + '"]').remove();
			        $('<script>').attr('src', src).appendTo('head');
			    }
			    reload_js('static/data/bubble_parameters.js');
			   
			    d3.selectAll("#toolbar > *").remove();
			    $("#bubbleSVG").remove();
			   // reload_js('static/js/BootSideMenu.js')
			   // reload_js('static/js/ticket.js');
			    reload_js('static/js/bubblesTickets.js');
			    
			   callCount=1;
			}
		})//collap clicking 
		});//document ready 
		});//end of d3 json
	
function setupButtons() {
    // As the data is being loaded: setup buttons
    // Create the buttons
    // TODO: change this to use native d3js selection methods
    for (i = 0; i<BUBBLE_PARAMETERS.modes.length; i++) {
        var button_element = document.createElement("a");
        button_element.href = "#";
        if (i == 0) {
            button_element.className = "button active";
        } else {
            button_element.className = "button";
        }
        button_element.id = BUBBLE_PARAMETERS.modes[i].button_id;
        button_element.innerHTML = BUBBLE_PARAMETERS.modes[i].button_text;
        document.getElementById("toolbar").appendChild(button_element);
    }     

    // Handle button click
    // Set up the layout buttons to allow for toggling between view modes.
    d3.select('#toolbar')
        .selectAll('.button')
        .on('click', function () {
            // Remove active class from all buttons
            d3.selectAll('.button').classed('active', false);

            // Set the button just clicked to active
            d3.select(this).classed('active', true);

            // Get the id of the button
            var buttonId = d3.select(this).attr('id');
            toggleCollapMenu();
            // Switch the bubble chart to the mode of
            // the currently clicked button.
            myBubbleChart.switchMode(buttonId);
        });    
}
$(document).on("click", function(e) {
    if (e.target === document || e.target.tagName === "svg") {
        // Clicked on blank space
    	  console.log('clicked the page');
    	 $("circle").css("opacity",1).attr("r",rSwitch);
    }
});
setupButtons();
