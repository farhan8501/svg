//code to remove active style on level 1		
$(".levelOne ").removeAttr("style");
//code for slide menu 1
	function toggleCollapMenu(){
	$("#toolbar a").click(function() {
		var firstKey=this.id;
		$('#ticket_priority').removeClass('disable_a_href');
		switch (true) {
		case firstKey==="category_name":
		$('a.secondKey#ticket_status,a.secondKey#ticket_priority,a.secondKey#solutionLinked').removeClass("disable_a_href");
		$('a.secondKey#ticket_status,a.secondKey#ticket_priority,a.secondKey#solutionLinked').addClass("enable_bold");
		$('a.secondKey#category_name').removeClass("enable_bold");
		$('a.secondKey#category_name').addClass("disable_a_href"); 
		$('#item-1 a').addClass("disable_a_href");
		$('#item-3 a').removeClass("disable_a_href");
		$('#item-2 a').removeClass("disable_a_href");
		$('#item-4 a').removeClass("disable_a_href");
/*			$('#item-1').hide();
			$('a.secondKey#category_name').hide();
			$('a.secondKey#solutionLinked').show();
			$('a.secondKey#ticket_status').show();
			$('a.secondKey#ticket_priority').show();
			$('#item-2').show();
			$('#item-3').show();
			$('#item-4').show();*/
			break;
		case firstKey==="ticket_priority":
		$('a.secondKey#ticket_status,a.secondKey#category_name,a.secondKey#solutionLinked').removeClass("disable_a_href");
		$('a.secondKey#ticket_status,a.secondKey#category_name,a.secondKey#solutionLinked').addClass("enable_bold");
		$('a.secondKey#ticket_priority').removeClass("enable_bold");
		$('a#ticket_priority').addClass("disable_a_href");
		$('#item-3 a').addClass("disable_a_href");
		$('#item-1 a').removeClass("disable_a_href");
		$('#item-2 a').removeClass("disable_a_href");
		$('#item-4 a').removeClass("disable_a_href");
/*		$('#item-3').hide();
		$('a.secondKey#ticket_priority').hide();
		$('a.secondKey#solutionLinked').show();
		$('a.secondKey#ticket_status').show();
		$('a.secondKey#category_name').show();
		$('#item-1').show();
		$('#item-2').show();
		$('#item-4').show();*/
			break;
		case firstKey==="ticket_status":
		$('a.secondKey#category_name,a.secondKey#ticket_priority,a.secondKey#solutionLinked').removeClass("disable_a_href");
		$('a.secondKey#category_name,a.secondKey#ticket_priority,a.secondKey#solutionLinked').addClass("enable_bold");
		$('a.secondKey#ticket_status').removeClass("enable_bold");
		$('a.secondKey#ticket_status').addClass("disable_a_href");
		$('#item-2 a').addClass("disable_a_href");
		$('#item-3 a').removeClass("disable_a_href");
		$('#item-4 a').removeClass("disable_a_href");
		$('#item-1 a').removeClass("disable_a_href");
/*		$('#item-2').hide();
		$('a.secondKey#ticket_status').hide();
		$('a.secondKey#solutionLinked').show();
		$('a.secondKey#ticket_priority').show();
		$('a.secondKey#category_name').show();
		$('#item-1').show();
		$('#item-3').show();
		$('#item-4').show();*/
			break;
		case firstKey==="solutionLinked":
		$('a.secondKey#ticket_status,a.secondKey#ticket_priority,a.secondKey#category_name').removeClass("disable_a_href");
		$('a.secondKey#ticket_status,a.secondKey#ticket_priority,a.secondKey#category_name').addClass("enable_bold");
		$('a.secondKey#solutionLinked').removeClass("enable_bold");
		$('a.secondKey#solutionLinked').addClass("disable_a_href");
		$('#item-4 a').addClass("disable_a_href");
		$('#item-3 a').removeClass("disable_a_href");
		$('#item-2 a').removeClass("disable_a_href");
		$('#item-1 a').removeClass("disable_a_href");	
/*		$('#item-4').hide();
		$('a.secondKey#solutionLinked').hide();
		$('a.secondKey#ticket_status').show();
		$('a.secondKey#ticket_priority').show();
		$('a.secondKey#category_name').show();
		$('#item-1').show();
		$('#item-2').show();
		$('#item-3').show();*/
			break;
		case firstKey==="all":
			$('a.secondKey#ticket_status,a.secondKey#ticket_priority,a.secondKey#solutionLinked,a.secondKey#category_name').removeClass("disable_a_href");
			$('a.secondKey#ticket_status,a.secondKey#ticket_priority,a.secondKey#solutionLinked,a.secondKey#category_name').addClass("enable_bold");
			$('#item-1 a').removeClass("disable_a_href");
			$('#item-3 a').removeClass("disable_a_href");
			$('#item-2 a').removeClass("disable_a_href");
			$('#item-4 a').removeClass("disable_a_href");
				break;
		default:
		$('a.secondKey#ticket_status,a.secondKey#ticket_priority,a.secondKey#solutionLinked,a.secondKey#category_name').removeClass("disable_a_href");
		$('a.secondKey#ticket_status,a.secondKey#ticket_priority,a.secondKey#solutionLinked,a.secondKey#category_name').addClass("enable_bold");
		$('#item-1 a').removeClass("disable_a_href");
		$('#item-3 a').removeClass("disable_a_href");
		$('#item-2 a').removeClass("disable_a_href");
		$('#item-4 a').removeClass("disable_a_href");
		}
	})
	}

/*$('#category_name').click(function(){
	$('a#ticket_status,a#ticket_priority,a#solutionLinked').removeClass("disable_a_href");
	$('a#ticket_status,a#ticket_priority,a#solutionLinked').addClass("enable_bold");
	$('a#category_name').removeClass("enable_bold");
	$('a#category_name').addClass("disable_a_href"); 
	$('#item-1 a').addClass("disable_a_href");
	$('#item-3 a').removeClass("disable_a_href");
	$('#item-2 a').removeClass("disable_a_href");
	$('#item-4 a').removeClass("disable_a_href");
	
});
$('#ticket_priority').click(function(){
	$('a#ticket_status,a#category_name,a#solutionLinked').removeClass("disable_a_href");
	$('a#ticket_status,a#category_name,a#solutionLinked').addClass("enable_bold");
	$('a#ticket_priority').removeClass("enable_bold");
	$('a#ticket_priority').addClass("disable_a_href");
	$('#item-3 a').addClass("disable_a_href");
	$('#item-1 a').removeClass("disable_a_href");
	$('#item-2 a').removeClass("disable_a_href");
	$('#item-4 a').removeClass("disable_a_href");
});
$('#ticket_status').click(function(){
	$('a#category_name,a#ticket_priority,a#solutionLinked').removeClass("disable_a_href");
	$('a#category_name,a#ticket_priority,a#solutionLinked').addClass("enable_bold");
	$('a#ticket_status').removeClass("enable_bold");
	$('a#ticket_status').addClass("disable_a_href");
	$('#item-2 a').addClass("disable_a_href");
	$('#item-3 a').removeClass("disable_a_href");
	$('#item-4 a').removeClass("disable_a_href");
	$('#item-1 a').removeClass("disable_a_href");
});
$('#solutionLinked').click(function(){
	$('a#ticket_status,a#ticket_priority,a#category_name').removeClass("disable_a_href");
	$('a#ticket_status,a#ticket_priority,a#category_name').addClass("enable_bold");
	$('a#solutionLinked').removeClass("enable_bold");
	$('a#solutionLinked').addClass("disable_a_href");
	$('#item-4 a').addClass("disable_a_href");
	$('#item-3 a').removeClass("disable_a_href");
	$('#item-2 a').removeClass("disable_a_href");
	$('#item-1 a').removeClass("disable_a_href");
});*/
//code for slide menu 
$(document).ready(function () {
    $('#collapsibleMenu1').BootSideMenu({
  	  // 'left' or 'right'
  	  side: "right",

  	  // animation speed
  	  duration: 500,

  	  // restore last menu status on page refresh
  	  remember: false,

  	  // auto close
  	  autoClose: true,

  	  // push the whole page
  	  pushBody: true,

  	  // close on click
  	  closeOnClick: true,

  	  // width
  	  width: "15%"
    });
    
/*    $('#collapsibleMenu2').BootSideMenu({

    	  // 'left' or 'right'
    	  side: "right",

    	  // animation speed
    	  duration: 500,

    	  // restore last menu status on page refresh
    	  remember: false,

    	  // auto close
    	  autoClose: true,

    	  // push the whole page
    	  pushBody: false,

    	  // close on click
    	  closeOnClick: true,

    	  // width
    	  width: "15%"
    	  
    	});*/
});
$(document).ready(function () {
$('#collapsibleMenu1').hide().css("visibility", "hidden");
//$('#collapsibleMenu2').hide().css("visibility", "hidden");
});
hideRelevantDonut();
//code to hide donut on initial page load
function hideRelevantDonut(){
	//document.getElementById("incident").innerHTML="";
$('#widget1').hide();
$('#widget2').hide();
$('#widget3').hide();
$('#widget4').hide();
$('#myButton').hide();
//$('#incident').hide();
}