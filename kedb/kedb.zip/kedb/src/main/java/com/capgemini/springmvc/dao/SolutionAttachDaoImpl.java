package com.capgemini.springmvc.dao;

import java.util.List;

import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.springframework.stereotype.Repository;

import com.capgemini.springmvc.model.AllSolutions;
import com.capgemini.springmvc.model.AttachmentFile;
import com.capgemini.springmvc.model.Solution;
import com.capgemini.springmvc.model.Solutionfile;

@Repository("solutionAttachDao")
public class SolutionAttachDaoImpl extends AbstractDao<Integer, AttachmentFile> implements SolutionAttachDao {

	@Override
	 public AttachmentFile findById(int id) {
	        return getByKey(id);
	    }

	@Override
	public void saveFile(AttachmentFile file) {
		    persist(file);
	}
	 
	@Override
	 public List<AttachmentFile>  findBySolutionId(int id){
		Session session = getSession();
		String sql_query = "SELECT * FROM kedb.solution_attachment where solution_id =:solutionid";
		SQLQuery query = session.createSQLQuery(sql_query);
		query.setParameter("solutionid", id);
		query.addEntity(AttachmentFile.class);
		List<AttachmentFile> result = query.list();
		return result;
	}
	
	@Override
	 public List<AttachmentFile> findfileBySolutionId(int id){
		Session session = getSession();
		String sql_query = "SELECT id, name FROM kedb.solution_attachment where solution_id =:solutionid";
		SQLQuery query = session.createSQLQuery(sql_query);
		query.setParameter("solutionid", id);
		query.addEntity(Solutionfile.class);
		List<AttachmentFile> result = query.list();
		return result;
	}
	
	@Override
	 public void deleteSolutionByID(int solutionid, int id){
		Session session = getSession();
		 String sql_query = "delete from solution_attachment where solution_id="+solutionid+" and id= "+id+" ";
		 SQLQuery query = session.createSQLQuery(sql_query);
		 query.executeUpdate();
	}
	 
}
