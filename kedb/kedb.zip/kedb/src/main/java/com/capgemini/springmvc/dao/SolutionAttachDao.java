package com.capgemini.springmvc.dao;

import java.util.List;

import com.capgemini.springmvc.model.AttachmentFile;

public interface SolutionAttachDao {

	AttachmentFile findById(int id);
	
	void saveFile(AttachmentFile file);
	
	List<AttachmentFile>  findBySolutionId(int id);
	
	List<AttachmentFile> findfileBySolutionId(int id);
	
	void deleteSolutionByID(int solutionid, int id);
}
