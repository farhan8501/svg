package com.capgemini.springmvc.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "SOLUTION_STATUS")
public class SolutionStatus {
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "STATUS_ID")
	private Integer statusId;
	
	@NotEmpty
	@Column(name = "SOLUTION_STATUS_NAME")
	private String solution_status_name;

	public Integer getStatusId() {
		return statusId;
	}

	public void setStatusId(Integer statusId) {
		this.statusId = statusId;
	}

	public String getSolution_status_name() {
		return solution_status_name;
	}

	public void setSolution_status_name(String solution_status_name) {
		this.solution_status_name = solution_status_name;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((solution_status_name == null) ? 0 : solution_status_name.hashCode());
		result = prime * result + ((statusId == null) ? 0 : statusId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SolutionStatus other = (SolutionStatus) obj;
		if (solution_status_name == null) {
			if (other.solution_status_name != null)
				return false;
		} else if (!solution_status_name.equals(other.solution_status_name))
			return false;
		if (statusId == null) {
			if (other.statusId != null)
				return false;
		} else if (!statusId.equals(other.statusId))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "SolutionStatus [statusId=" + statusId + ", solution_status_name=" + solution_status_name + "]";
	}

	
	
}
