package com.capgemini.springmvc.service;

import java.util.List;

import com.capgemini.springmvc.model.AppCategory;
import com.capgemini.springmvc.model.ApplicationCategory;
import com.capgemini.springmvc.model.Solution;
import com.capgemini.springmvc.model.Subcategory;

public interface ApplicationCategoryService {

	List<ApplicationCategory> findAllCategories();
	ApplicationCategory findById(int id);
	List<AppCategory> findCategories();
	List<Subcategory> getAllSubcategories(String categoryName);
	void savenewCagetory(AppCategory applicationCategory);
	void deletecategoryName(String categoryName);
	List<AppCategory> getAllcategories();
	

}
