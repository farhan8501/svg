package com.capgemini.springmvc.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "SOLUTION")
public class Solutionstop {
	@Id
	@Column(name = "SOLUTIONS_ID") 
	private Integer id;
	
	@Column(name = "RATINGCLASSVALUE")
	private Integer rate;

	@Column(name = "COUNT")
	private Integer count;
	
	@Column(name = "SOLUTION_DESC")
	private String solution_desc;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getRate() {
		return rate;
	}

	public void setRate(Integer rate) {
		this.rate = rate;
	}

	public Integer getCount() {
		return count;
	}

	public void setCount(Integer count) {
		this.count = count;
	}

	public String getSolution_desc() {
		return solution_desc;
	}

	public void setSolution_desc(String solution_desc) {
		this.solution_desc = solution_desc;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((count == null) ? 0 : count.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((rate == null) ? 0 : rate.hashCode());
		result = prime * result + ((solution_desc == null) ? 0 : solution_desc.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Solutionstop other = (Solutionstop) obj;
		if (count == null) {
			if (other.count != null)
				return false;
		} else if (!count.equals(other.count))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (rate == null) {
			if (other.rate != null)
				return false;
		} else if (!rate.equals(other.rate))
			return false;
		if (solution_desc == null) {
			if (other.solution_desc != null)
				return false;
		} else if (!solution_desc.equals(other.solution_desc))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Solutionstop [id=" + id + ", rate=" + rate + ", count=" + count + ", solution_desc=" + solution_desc
				+ "]";
	}
	
	

	
	

}
