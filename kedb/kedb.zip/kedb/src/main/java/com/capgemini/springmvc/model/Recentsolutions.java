package com.capgemini.springmvc.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "SOLUTION")
public class Recentsolutions {
	
	@Id
	@Column(name = "SOLUTION_ID") 
	private Integer id;
	
	@Column(name = "SOLUTION_DESC")
	private String solution_desc;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getSolution_desc() {
		return solution_desc;
	}

	public void setSolution_desc(String solution_desc) {
		this.solution_desc = solution_desc;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((solution_desc == null) ? 0 : solution_desc.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Recentsolutions other = (Recentsolutions) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (solution_desc == null) {
			if (other.solution_desc != null)
				return false;
		} else if (!solution_desc.equals(other.solution_desc))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Recentsolutions [id=" + id + ", solution_desc=" + solution_desc + "]";
	}

	
}
