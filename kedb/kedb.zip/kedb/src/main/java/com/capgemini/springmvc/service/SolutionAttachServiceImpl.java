package com.capgemini.springmvc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.springmvc.dao.SolutionAttachDao;
import com.capgemini.springmvc.model.AttachmentFile;
import com.capgemini.springmvc.model.Incident;

@Service("solutionAttachService")
@Transactional
public class SolutionAttachServiceImpl implements SolutionAttachService {
	
	 @Autowired
	 SolutionAttachDao dao;

	public AttachmentFile findById(int id) {
        return dao.findById(id);
    }
	
	public void saveFile(AttachmentFile file){
		 dao.saveFile(file);
	}
	
	public List<AttachmentFile>  findBySolutionId(int id){
		 return dao.findBySolutionId(id);
	}
	
	public List<AttachmentFile> findfileBySolutionId(int id){
		 return dao.findfileBySolutionId(id);
	}
	
	public void deleteSolutionByID(int solutionid, int id){
		 dao.deleteSolutionByID(solutionid,id);
	}
	
	 
}
