package com.capgemini.springmvc.service;

import java.util.List;

import com.capgemini.springmvc.model.Incident;
import com.capgemini.springmvc.model.Subcategory;
import com.capgemini.springmvc.model.TicketCategory;
import com.capgemini.springmvc.model.TicketSeverity;
import com.capgemini.springmvc.model.Ticketstatus;

public interface IncidentService {

	public List<Incident> getAllIncidents();
	public List<Incident> getIncidentstatuscount();
	public List<Incident> getIncidentlinkedcount();
	public Incident findById(int id);
	public List<Incident> getAllTickets();
	public Incident getTicket(int id);
	public List<Incident> getProfileTickets(String profileUser);
	public List<Incident> findAllCategories();
	void savenewticketcategory(TicketCategory ticketCategory);
	void deleteticketcategory(String ticketcategoryname);
	public List<Incident> findAllsubcategories();
	public List<Incident> findAllticketseverities();
	public List<Incident> findAllticketstatus();
	void savenewticketseverity(TicketSeverity ticketseverity);
	void deleteticketseverity(String ticketsseverity);
	void savenewsubcategory(Subcategory subcategory);
	void deletesubcategory(String subcategory);
	void savenewticketstatus(Ticketstatus ticketstatus);
	void deleteticketticketstatus(String ticketstat);
	public List<Incident> searchticketid(String id);
	public List<Incident> searchticketdesc(String desc);
	public List<Incident> getAllticketSeverity();
	public List<Incident> getAllticketStatus();
}
