package com.capgemini.springmvc.service;

import java.util.List;

import com.capgemini.springmvc.model.AttachmentFile;

public interface SolutionAttachService {
	AttachmentFile findById(int id);
	void saveFile(AttachmentFile file);
	List<AttachmentFile>  findBySolutionId(int id);
	List<AttachmentFile> findfileBySolutionId(int id);
    void deleteSolutionByID(int solutionid, int id);

}
